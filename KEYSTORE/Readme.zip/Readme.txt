Pandroid.injected.signing.store.password=avoqadro0
Pandroid.injected.signing.key.alias=mykey
Pandroid.injected.signing.key.password=avoqadro0